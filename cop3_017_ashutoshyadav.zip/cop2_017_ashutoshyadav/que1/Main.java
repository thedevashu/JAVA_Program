
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address ad =new Address("102","zvv","aewrf","erf","awrf","erf","400234");
		System.out.println(ad);
	}

}

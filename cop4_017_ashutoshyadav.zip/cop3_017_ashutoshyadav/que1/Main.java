
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AreaCalculactor c=new AreaCalculactor();
		c.area(3f);
		c.circumference();

	}

}


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JavaLoop.power(2, 3);
		JavaLoop.fibo(9);
		JavaLoop.prime(100);
	}

}

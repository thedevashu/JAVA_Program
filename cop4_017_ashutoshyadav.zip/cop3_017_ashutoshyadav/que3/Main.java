
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayFun a= new ArrayFun();
		int arr[] = {1,5,2,4,3,4};
		a.setArr(arr);
		a.intertArr(23, 3);
		a.right_rotate();
		a.left_rotate();
		a.sortArr();
	}

}
